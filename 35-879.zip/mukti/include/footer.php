<footer class="footer">
		<div class="container">
			<div class="row">
				<div class="col-md-4">
					<ul>
						<li> <a href="">About Us</a></li>
						<li> <a href="">Contact Us</a></li>
						<li> <a href="">Get Help</a></li>

						
					</ul>
				</div>
				
				<div class="col-md-4 pull-right">
					<h4 class="address"><span class="glyphicon glyphicon-home"></span> Location</h4>
					<address>
						Sukrabad, Dhanmondi 32,<br>
						Dhaka Bangladesh.
					</address>
				</div>
			</div>
		</div>
	</footer>

	<div class="modal fade well" id="login" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
		    <div class="modal-content">
			    <div class="modal-header">
			        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			        <h4 class="modal-title text-center" id="myModalLabel">Login Here</h4>
			    </div>
			    <form method="post" name="login-portal" class="form-horizontal">
			      <div class="modal-body">
			       	<div class="form-group">
			       		<div class="col-xs-3 text-center">
			       			User Name
			       		</div>
			       		<div class="col-xs-6">
			       			<input type="text" name="useremail" class="form-control" required>
			       		</div>
			       	</div>
			       	<div class="form-group">
			       		<div class="col-xs-3 text-center">
			       			Password
			       		</div>
			       		<div class="col-xs-6">
			       			<input type="password" name="password" class="form-control" required>
			       		</div>
			       	</div>
			      </div>
			      <div class="modal-footer">
			        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			        <button type="submit" name="login-click" class="btn btn-primary">Login</button>
			      </div>
			    </form>
		    </div>
		</div>
	</div>

	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
</body>
</html>