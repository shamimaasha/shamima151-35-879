<?php
	include 'controller/controller.php';

?>
<!DOCTYPE html>
<html>
<head>
	<title>website</title>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" href="font_awesome/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">

</head>
<body>

	<div class="container-fluid head-top hidden-xs">
		<div class="row">
			<div class="col-md-4">
				<img src="image/img1.jpg" class="img-responsive pull-right" width="130" height="100">
			</div>
			<div class="col-md-7">
				<div class="row">
					<img src="image/logo.jpg"  class="pull-right" height="80" style="margin-top:35px;">
				</div>
				<div class="row text-right">
					<a href="#"><i class="fa fa-facebook fa-lg btn" aria-hidden="true"></i></a>
					<a href="#"><i class="fa fa-twitter fa-lg btn" aria-hidden="true"></i></a>
				</div>				
			</div>
		</div>
	</div>

	<nav class="navbar navbar-inverse">
		<div class="container">
		    <div class="navbar-header">
		      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
		        <span class="sr-only">Toggle navigation</span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		      </button>
		      <a class="navbar-brand text-uppercase" href="index.html"><img src="image/logo.jpg" width="150" height="50"></a>
			</div>
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			    <ul class="nav navbar-nav">		        
			        <li><a href="index.php">Home</a></li>
			        <li><a href="#">About us </a></li>
			        <li><a href="#">Contact us</a></li>
			        <li><a href="#">View Course</a></li>
			        <li><a href="#">Add Course</a></li>
			        <li><a href="#">Drop Course</a></li>
			    </ul>
			    <ul class="nav navbar-nav navbar-right">		        
			        <li class="dropdown">
				        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-user"></span> <span class="caret"></span></a>
				        <ul class="dropdown-menu">
				        	<?php
				        		if(empty($_SESSION['user']))
				        		{
				        			echo '<li><a href="#" data-toggle="modal" data-target="#login">Login</a></li>';
				        		}
				        		else
				        		{
				        			echo '<li><a href="?logout-user">Logout</a></li>';
				        		}
				        	?>				            
				        </ul>
				    </li>
			    </ul>
			</div>
		</div>
	</nav>