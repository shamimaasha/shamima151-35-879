<?php 
	session_start();

	// Search schedule
	
?>