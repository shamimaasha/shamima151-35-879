<?php
	include 'include/menu.php';
?>
	
<div class="container" style="margin-bottom: 20px;">
	<div class="row">
		<div class="col-sm-5">
			<img src="image/img1.jpg" class="img-responsive">
		</div>
		<div class="col-sm-6">
			Here A short Note About university<br>
			Here A short Note About university<br>
			Here A short Note About university<br>
			Here A short Note About university<br>
			Here A short Note About university<br>
			Here A short Note About university<br>
			Here A short Note About university<br>
			Here A short Note About university<br>
			Here A short Note About university<br>
		</div>
	</div>
</div>

<?php
	include 'include/footer.php';
?>